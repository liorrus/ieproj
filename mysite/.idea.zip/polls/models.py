
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
import datetime
from django.contrib.auth.models import User
from django.conf import settings
from django.urls import reverse
from django.http import HttpResponseRedirect
import datetime


class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')
    
    def __str__(self):
        return self.question_text
    
    def was_published_recently(self):
        return self.pub_date >= timezone.now() -  datetime.timedelta(days=1)


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)
    
    def __str__(self):
        return self.choice_text


class Product(models.Model):
    pdes = models.CharField(max_length=48)  # description
    price = models.IntegerField(default=0)  # price of product
    prep = models.FloatField(default=0.0)  # time for preparation
    slug = models.SlugField(default="STRING")

    def get_absolute_url(self):
        return reverse('polls:product_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return self.pdes

    def get_name(self):
        return str(self.pdes) + " // " + str(self.price) + " // " + str(self.pk)


class Unit(models.Model): 
    unit_des = models.CharField(max_length=13) # kg, m, box, etc     

    def __str__(self):
        return self.unit_des


class Part(models.Model): # Raw material 
    pdes = models.CharField(max_length=48) # material description
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE) # the foreign key is the id of question
    stock = models.FloatField(default=0.0) # How Much are in current stock
    lt = models.FloatField(default=1.0) # time to deliver
    sshigh = models.FloatField(default=0) 
    sslow = models.FloatField(default=0)
    slug = models.SlugField(default="STRING")

    def get_absolute_url(self):
        return reverse('polls:part_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return self.pdes

    def get_name(self):
        return str(self.pdes) + " // " + str(self.stock)


class Pip(models.Model):
    part = models.ForeignKey(Part, on_delete=models.CASCADE)
    quant = models.FloatField(default=0.0)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    class Meta:
        unique_together = (("part", "product"),)  # used for double column primary key

    def get_absolute_url(self):
        return reverse('polls:pip_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.part) + " " + str(self.quant) + " " + str(self.product)

    def get_name(self):
        return str(self.part) + " // " + str(self.quant) + " // " + str(self.product)


class NewExtra(models.Model):
    extra_part = models.ForeignKey(Part, on_delete=models.CASCADE)
    extra_price = models.FloatField(default=0.0)
    extra_product = models.ForeignKey(Product, on_delete=models.CASCADE)

    def get_absolute_url(self):
        return reverse('polls:newextra_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.extra_part.pdes) + " " + str(self.extra_price) + " " + str(self.extra_product)

    def get_name(self):
        return str(self.extra_part) + " // " + str(self.extra_price) + " // " + str(self.extra_product)


class Supplier(models.Model):
    name = models.CharField(max_length=200)  # supplier name
    address = models.CharField(max_length=200)  # supplier address
    tel = models.CharField(max_length=200)  # supplier telephone
    mail = models.EmailField(max_length=200)  # supplier mail
    slug = models.SlugField(default="STRING")

    def get_absolute_url(self):
        return reverse('polls:supplier_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.name) + " " + str(self.address) + " " + str(self.tel) + " " + str(self.mail)

    def get_name(self):
        return str(self.name) + " // " + str(self.address)


class SupPrice(models.Model):
    supplier = models.ForeignKey(Supplier,null=False, on_delete=models.CASCADE) #supplier name
    part = models.ForeignKey(Part, null=False, on_delete=models.CASCADE)
    price = models.FloatField(max_length=200)
    slug = models.SlugField(default="STRING")

    class Meta:
        unique_together = (("supplier", "part"),)  # used for double column primary key

    def __str__(self):
        return str(self.supplier.name) + " " + str(self.part) + " " + str(self.price)

    def get_absolute_url(self):
        return reverse('polls:supprice_detail', kwargs={'pk': self.pk})

    def get_name(self):
        return str(self.supplier.name) + " // " + str(self.part.pdes) + " // " + str(self.price)


class Components(models.Model):
    part = models.ForeignKey(Part, on_delete=models.CASCADE)
    quant = models.FloatField(default=0.0)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)  # component to product

    def get_absolute_url(self):
        return reverse('polls:components_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.part) + " " + str(self.quant) + " " + str(self.product)

    def get_name(self):
        return str(self.part) + " // " + str(self.quant) + " // " + str(self.product)


now = datetime.datetime.now()


class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # costumer ID
    orderDate = models.DateTimeField(auto_now_add=True)  # the date of order creation
    orderPick=models.DateTimeField(blank=True, default=now)
    ORDER_STATUS = (
        ('W', 'WAITING'),
        ('R', 'READY'),
        ('T', 'TAKE'),
    )
    orderStatus = models.CharField(max_length=1, choices=ORDER_STATUS, default='WAITING') 
    remarks = models.CharField(max_length=300, default="-none-")  # remarks of the order
    ifSupplied = models.BooleanField(default=False)
    product1 = models.ForeignKey(Product, null=False, on_delete=models.CASCADE, related_name="pro1")  # product ID
    product2 = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="pro2", default=52)  # product ID
    product3 = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="pro3", default=52)  # product ID
    extra1 = models.ForeignKey(NewExtra, on_delete=models.CASCADE, related_name="ex1", default=3)  # extra1 if have
    extra2 = models.ForeignKey(NewExtra, on_delete=models.CASCADE, related_name="ex2", default=3)  # extra2 if have
    extra3 = models.ForeignKey(NewExtra, on_delete=models.CASCADE, related_name="ex3", default=3)  # extra3 if have
    extra4 = models.ForeignKey(NewExtra, on_delete=models.CASCADE, related_name="ex4", default=3)  # extra4 if have
    extra5 = models.ForeignKey(NewExtra, on_delete=models.CASCADE, related_name="ex5", default=3)  # extra5 if have
    component1 = models.ForeignKey(Components, on_delete=models.CASCADE, related_name="comp1", default=6)  # component1 if have
    component2 = models.ForeignKey(Components, on_delete=models.CASCADE, related_name="comp2", default=6)  # component2 if have
    component3 = models.ForeignKey(Components, on_delete=models.CASCADE, related_name="comp3", default=6)  # component3 if have
    component4 = models.ForeignKey(Components, on_delete=models.CASCADE, related_name="comp4", default=6)  # component4 if have
    component5 = models.ForeignKey(Components, on_delete=models.CASCADE, related_name="comp5", default=6)  # component5 if have

    def get_absolute_url(self):
        return reverse('polls:order_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.user) + " " + str(self.orderDate) + " " + str(self.remarks) + " " + str(self.orderStatus) +\
               " " + str(self.ifSupplied) + " " + str(self.orderPick) + " " + str(self.id)

    def get_name(self):
        return str(self.user) + " //product1: " + str(self.product1) + " ,product2: " + str(self.product2) \
               + " ,product3: " + str(self.product3) + " // " + str(self.orderDate) + " // " + str(self.orderStatus) \
               + " // " + str(self.id)


class POrder(models.Model):
    supplier = models.ForeignKey(Supplier, null=False, on_delete=models.CASCADE)  # product ID
    ORDER_STATUS = (
        ('W', 'WAITING'),
        ('R', 'READY'),
        ('T', 'TAKE'),
    )
    orderStatus = models.CharField(max_length=1, choices=ORDER_STATUS, default='WAITING')
    porderDate = models.DateTimeField(auto_now_add=True)  # the date of order creation
    ifSupplied = models.CharField(max_length=1)

    def get_absolute_url(self):
        return reverse('polls:pord_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.supplier.name) + " " + str(self.orderStatus) + " " + str(self.porderDate)

    def get_name(self):
        return str(self.supplier.name) + " // " + str(self.orderStatus) + " // " + str(self.porderDate) \
               + " // " + str(self.ifSupplied)


class POrderItem(models.Model):
    porder = models.ForeignKey(POrder, null=False,on_delete=models.CASCADE)  # product ID
    part = models.ForeignKey(Part, null=False,on_delete=models.CASCADE)  # product ID
    quant = models.FloatField(max_length=200)

    class Meta:
        unique_together = (("part", "porder"),)  # used for double column primary key

    def get_absolute_url(self):
        return reverse('polls:porderitem_detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.porder) + " " + str(self.part) + " " + str(self.quant)

    def get_name(self):
        return str(self.porder) + " // " + str(self.part) + " // " + str(self.quant)


def get_first_name(self):
    return str(self.username)




User.add_to_class("__str__", get_first_name)
